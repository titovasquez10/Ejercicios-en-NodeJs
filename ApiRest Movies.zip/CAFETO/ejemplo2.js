var list = [];

for (let index = 1; index <= 100; index++) {
    
    list.push(index);
    
    
}


console.log(list);