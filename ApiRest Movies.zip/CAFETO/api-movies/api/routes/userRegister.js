const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");


const UserRegister = require("../models/userRegister");

//METODO PARA SIGNUP

router.post("/signup", (req, res, next) => {
    console.log("Data: ", req);
    UserRegister.find({ email: req.body.email })
       .exec()
         .then(userregister1 => { //CONDICION PARA SABER SI EL EMAIL PARA EXISTE
           if (userregister1.length >= 1) {
             return res.status(409).json({
               message: "Mail exists"
               });
             } else {
                 bcrypt.hash(req.body.password, 10, (err, hash) => { //METODO PARA ENCRIPTAR EL PASSWORD
                    if (err) {
                     return res.status(500).json({
                         error: err
                       });
                      } else {
                        const userregister1 = new UserRegister({
                           _id: new mongoose.Types.ObjectId(),
                           idUser: req.body.idUser,
                           nameUser: req.body.nameUser,
                           email: req.body.email,
                           password: hash,
                         });
                       userregister1
                             .save()
                             .then(result => {
                               console.log(result);
                                 res.status(201).json({
                                     message: "User Created",
                                     idUser: req.body.idUser,
                                     nameUser: req.body.nameUser,
                                     email: req.body.email,
                                     request: {
                                       type: 'GET',
                                       url: 'http://localhost:3000/userRegister/' + result.email
                                     }
                                   });
                                 })
                                 .catch(err => {
                                   console.log(err);
                                   res.status(500).json({
                                     error: err
                                   });
                                 });
                             }        
                         });
                     }
                   
               });
     });

//METODO PARA LOGIN

router.post("/login", (req, res, next) => {
    UserRegister.find({ email: req.body.email })
      .exec()
      .then(userregister1 => {
        if (userregister1.length < 1) {
          return res.status(401).json({
            message: "Auth failed"
          });
        }
        bcrypt.compare(req.body.password, userregister1[0].password, (err, result) => {
          if (err) {
            return res.status(401).json({
              message: "Auth failed"
            });
          }
          if (result) {
            const token = jwt.sign(
              {
                email: userregister1[0].email,
                userId: userregister1[0]._id
              },
              process.env.JWT_KEY,
              {
                expiresIn: "1h"
              }
            );
            return res.status(200).json({
              message: "Auth successful",
              token: token
            });
          }
          res.status(401).json({
            message: "Auth failed, try again"
          });
        });
      })
      .catch(err => {
        console.log(err);
        res.status(500).json({
          error: err
        });
      });
  });

//METODO PARA GET ALL
  router.get("/", (req, res, next) => {
    UserRegister.find()
    .select( 'idUser nameUser email' ) // fech data form show response
      .exec()
      .then(docs => {
        console.log(docs);
        const response = {
          count: docs.length,
          UserRegister: docs.map(doc => {
            return {
              _id : doc.id,
              idUser: doc.idUser,
              nameUser: doc.nameUser,
              email: doc.email,
              request: {
                type: 'GET',
                url: 'http://localhost:3000/userRegister/' + doc.idUser
              }
            }
          })
        };
        //   if (docs.length >= 0) {
        res.status(200).json(response);
        //   } else {
        //       res.status(404).json({
        //           message: 'No entries found'
        //       });
        //   }
      })
      .catch(err => {
        console.log(err);
        res.status(500).json({
          error: err
        });
      });
  });

//METODO PARA GET BY ID
router.get("/:idUser", (req, res, next) => {
    const id = req.params.idUser;
    UserRegister.find({ idUser : id })
      .exec()
      .then(doc => {
        console.log("From database", doc);
        if (doc) {
          res.status(200).json({
            idUser: doc,
            request: {
              type: 'GET',
              descripcion: 'Get All Data User Register System',
              url: 'http://localhost:3000/userRegister/'
            }
          });
        } else {
          res
            .status(404)
            .json({ message: "No valid entry found" }); 
        }
      })
      .catch(err => {
        console.log(err);
        res.status(500).json({ error: err });
      });
  });
  
//METODO DE DELETE
router.delete("/:email",(req, res, next) => {
  
  UserRegister.remove({ _id: req.params.email })
      .exec()
      .then(result => {
        res.status(200).json({
          message: "User deleted"
        });
      })
      .catch(err => {
        console.log(err);
        res.status(500).json({
          error: err
        });
      });
  });
  
  
  module.exports = router;
  

