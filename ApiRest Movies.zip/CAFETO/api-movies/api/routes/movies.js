const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");

const Movies = require("../models/movies");

//GET MOVIES
router.get("/", (req, res, next) => {
    Movies.find()
      .select( 'idMovie nameMovie genreMovie imDBVotes country yearMovie directedBy' ) // fech data form show response
        .exec()
          .then(docs => {
            //console.log(docs);
              const response = {
                count: docs.length,
                    MoviesData: docs.map(doc => {
                    return {
                        idMovie: doc.idMovie,
                        nameMovie: doc.nameMovie,
                        genreMovie: doc.genreMovie,
                        imDBVotes: doc.imDBVotes,
                        country: doc.country,
                        yearMovie: doc.yearMovie,
                        directedBy: doc.directedBy,
                        request: {
                          type: 'GET',
                          url: 'http://localhost:3000/movies/' + doc.nameMovie
                        }
                    }
                  })
              };
              //   if (docs.length >= 0) {
              res.status(200).json(response);
              //   } else {
              //       res.status(404).json({
              //           message: 'No entries found'
              //       });
              //   }
          })
        .catch(err => {
          console.log(err);
            res.status(500).json({
            error: err
          });
        });
  });

//POST MOVIE
router.post("/", (req, res, next) => {
    console.log("Data: ", req);
    Movies.find({idMovie: req.body.idMovie})
    .exec()      
      .then( doc => {
        
          console.log(doc)
            if(doc.length >= 1){
  
              if (doc[0].idMovie == req.body.idMovie) {
                console.log("Resputesta",doc.body)
                  return res.status(404).json({
                message: "id movie already exists, try again"
              })
        }
    }
          const movies = new Movies({
            _id: new mongoose.Types.ObjectId(),
            idMovie: req.body.idMovie,
            nameMovie: req.body.nameMovie,
            genreMovie: req.body.genreMovie,
            imDBVotes: req.body.imDBVotes,
            country: req.body.country,
            yearMovie: req.body.yearMovie,
            directedBy: req.body.directedBy,
            });
        movies
          .save()
            .then(result => {
            console.log(result);
              res.status(201).json({
                message: "Movie Created",
                createdMovies: result,
                  request: {
                  type: 'GET',
                  url: 'http://localhost:3000/movies/' + result.nameMovie
                }
              });
            })
      .catch(err => {
        console.log(err);
        res.status(500).json({
          message: "1. Error POST requests to /movies",
          error: err
        });
      });
    })
});

//GET by idMovie and yearMovie
router.get("/:IdM", (req, res, next) => {
    const id = req.params.IdM;
    Movies.findById(id)
      //ObdData.findById(id)
      //console.log("VIN: ", id);
      Movies.find({$or:[{idMovie : id},{yearMovie : id}] } )
      .exec()
        .then(doc => {
          console.log("From database", doc);
            if (doc.length >= 1) {
              res.status(200).json({
                movies1: doc,
                  request: {
                    type: 'GET',
                    descripcion: 'Movies',
                    url: 'http://localhost:3000/movies/'
                  }
              });
            } else {
          res
            .status(404)
            .json({ message: "No valid entry found for provided Id Movies or year movies" });
        }
      })
      .catch(err => {
        console.log(err);
        res.status(500).json({ error: err });
      });
  });
  
//PATCH
router.patch("/:movieId", (req, res, next) => {
    const id = req.params.movieId;
      const updateOps = {};

        for (const ops of req.body) {
          updateOps[ops.propName] = ops.value;
        }
    Movies.update({ idMovie : id }, { $set: updateOps })
      .exec()
        .then(result => {
          console.log(result);
            res.status(200).json({
              message: "Update ID Movie: " + id,
              movied2: result,
                request: {
                  descripcion: 'Updated movie',
                  type: 'GET',
                  url: 'http://localhost:3000/movies/' + id
                }
            });
        })
      .catch(err => {
        console.log(err);
        res.status(500).json({
          error: err
        });
      });
  });

//DELETE MOVIES BY ID
router.delete("/:IdM", (req, res, next) => {
    const id = req.params.IdM;
      Movies.remove({ idMovie : id })
      .exec()
        .then(result => {
          /* PENDIENTE
          console.log("Result Data: " + result.n);
          if(result.n == 0)
          state = "does not exist";
          else
          state = "has been deleted";
          */
          res.status(200).json({
              //result: state,
            status: result,
            message: "Movie " + id + " Delete.",
              request: {
                type: 'GET',
                descripcion: 'Movies',
                url: 'http://localhost:3000/movies/'
              }
          });
  
          })
      .catch(err => {
        console.log(err);
        res.status(500).json({
          error: err
        });
      });
  });
  
  module.exports = router;



  


