const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");

const UserLogin = require("../models/userLogin");
const Movies = require("../models/movies");
//const UserRegister = require("../models/userRegister");

//GET
router.get("/", (req, res, next) => {
    UserLogin.find()
    .select( 'idUser nameUser commentsMovie movieRating registry' ) //ESTA PARTE ES PARA CUANDO SE HAGA EL GET Y LO Q SE QUIERE MOSTRAR
    .exec()
    .then(docs => {
      //console.log(docs);
      const response = {
        count: docs.length,
        ResellerUserData: docs.map(doc => {
          return {
            idUser: doc.idUser,
            nameUser: doc.nameUser,
            commentsMovie: doc.commentsMovie,
            movieRating: doc.movieRating,
            registry: [{
                idMovie: doc.registry.idMovie,              
                nameMovie: doc.registry.nameMovie,
                yearMovie: doc.registry.yearMovie,          
            }], 
              request: {
                type: 'GET',
                url: 'http://localhost:3000/userLogin/' + doc.idUser,
                }
          }
        })
      };
      //   if (docs.length >= 0) {
      res.status(200).json(response); //AQUI SE PASA RESPONSE PARA LO Q QUEREMOS MOSTRAR
      //   } else {
      //       res.status(404).json({
      //           message: 'No entries found'
      //       });
      //   }
    })
    .catch(err => {
      console.log(err);
      res.status(500).json({
        error: err
      });
    });
});


//METODO POST
router.post("/", (req, res, next) => {
  var score = 5;
  const id = req.body.registry.idMovie;

    if(id == ""){
      return res.status(200).json({
        message: 'id Reseller Company it´s null'      
        })
      }
      console.log("Data: ", id); 

      UserLogin.find({$or: [{idUser: req.body.idUser}, {movieRating: req.body.movieRating}] } )
        .exec()    
          .then(doc => {
            console.log("User doc: ", doc);
              
            if(doc.length >= 1){

              if (doc[0].idUser == req.body.idUser) {
                console.log("Resputesta",doc.body)
                return res.status(404).json({
                  message: "id reseller user already exists, try again"
                })  
                }
                
            if (doc[0].commentsMovie >= score) {
                console.log("Resputesta",doc.body)
                    return res.status(404).json({
                  message: "The score must be between 1 and 5"
                })
              
                }

              }       
            Movies.findOne( {  idMovie : id } )
        
            .exec()  
              .then(doc => {
                company = req.body.registry.idMovie;
                if(doc.idMovie == company){

                  company = doc.idMovie;
                  console.log("doc: ", doc.idMovie);
                     
                    const userlogin = new UserLogin({
                      _id: new mongoose.Types.ObjectId(),
                      idUser: req.body.idUser,
                      nameUser: req.body.nameUser,
                      commentsMovie: req.body.commentsMovie,
                      movieRating: req.body.movieRating,                    
                        registry: {
                          idMovie: company,     
                          nameMovie: doc.nameMovie,
                          yearMovie: doc.yearMovie,                            
                        }
                      });
                    
                  userlogin 
                    .save()
                      .then(result => {
                        console.log(result);
                          res.status(201).json({
                            message: "Handling POST requests to /userLogin",
                            createdresellerusers : result,
                              request: {
                                type: 'GET',
                                url: 'http://localhost:3000/userLogin/' + result.idResellerUser
                                }
                            });
                        })
                  
                        .catch(err => {
                          res.status(500).json({
                            message: 'User does´t exist',
                            error: err
                            });
                        });    
                                                              
                }        
                                                                                
                }) 
                  .catch(err => {
                    res.status(500).json({
                      message: 'Movies does´t exist',
                      error: err
                      });
                  }); 
            })         
  });


//GET BY ID
router.get("/:IdUser", (req, res, next) => {
      const id = req.params.IdUser;
      UserLogin.findById(id)
      //ObdData.findById(id)
      //console.log("VIN: ", id);
      UserLogin.find({ idUser : id })
        .exec()
        .then(doc => {
          console.log("From database", doc);
          if (doc.length >= 1) {
            res.status(200).json({
              User: doc,
              request: {
                type: 'GET',
                descripcion: 'User',
                url: 'http://localhost:3000/userLogin/'
              }
            });
          } else {
            res
              .status(404)
              .json({ message: "No valid entry found for provided ID User Login" });
          }
        })
        .catch(err => {
          console.log(err);
          res.status(500).json({ error: err });
        });
    });
    
    
//METODO PATCH
router.patch("/:IdU", (req, res, next) => {
  const id = req.params.IdU;
  const updateOps = {};

  for (const ops of req.body) {
    updateOps[ops.propName] = ops.value;
  }
  UserLogin.update({ idUser : id }, { $set: updateOps })
    .exec()
    .then(result => {
      console.log(result);
      res.status(200).json({
        message: "Update USER: " + id,
        USER: result,
        request: {
          descripcion: 'Updated',
          type: 'GET',
          url: 'http://localhost:3000/userLogin/' + id
        }
      });
    })
    .catch(err => {
      console.log(err);
      res.status(500).json({
        error: err
      });
    });
});

// Handle incoming DELETE requests to /reselleruser
router.delete("/:IdUser", (req, res, next) => {
  const id = req.params.IdUser;
  UserLogin.remove({ idUser : id })
    .exec()
    .then(result => {
      /* PENDIENTE
      console.log("Result Data: " + result.n);
      if(result.n == 0)
        state = "does not exist";
      else
        state = "has been deleted";
      */
        res.status(200).json({
        //result: state,
        status: result,
        message: "Registry USER " + idUser + " Delete.",
        request: {
          type: 'GET',
          descripcion: 'Get All Data USERS System - Be Careful',
          url: 'http://localhost:3000/userLogin/'
        }
      });

    })
    .catch(err => {
      console.log(err);
      res.status(500).json({
        error: err
      });
    });
});

module.exports = router;


    






