const mongoose = require('mongoose');

const movies4Schema = mongoose.Schema({

    _id: mongoose.Schema.Types.ObjectId,
    idMovie: String,
    nameMovie: String,
    genreMovie: String,
    imDBVotes: String,
    country: String,
    yearMovie: String,
    directedBy: String,
});

module.exports = mongoose.model('Movies', movies4Schema);

//POST MOVIE
/*
{
    "idMovie" : "0001",
    "nameMovie" : "Transformers: The Last Knight",
    "genreMovie" : "Action",
    "imDBVotes" : "7.5",
    "country" : "United States",
    "yearMovie" : "2017",
    "directedBy" : "Michael Bay",
}

{
    "idMovie" : "0002",
    "nameMovie" : "It chapter two",
    "genreMovie" : "Terror",
    "imDBVotes" : "6.8",
    "country" : "United States",
    "yearMovie" : "2019",
    "directedBy" : "Andy Muschietti"
}

{
    "idMovie" : "0003",
    "nameMovie" : "Avengers: Endgame",
    "genreMovie" : "Action",
    "imDBVotes" : "9.5",
    "country" : "United States",
    "yearMovie" : "2019",
    "directedBy" : "Anthony Russo & Joe Russo"
}

{
    "idMovie" : "0004",
    "nameMovie" : "Aquaman",
    "genreMovie" : "Action",
    "imDBVotes" : "7.8",
    "country" : "United States",
    "yearMovie" : "2018",
    "directedBy" : "James Wan"
}

{
    "idMovie" : "0005",
    "nameMovie" : "A Star Is Born",
    "genreMovie" : "Drama",
    "imDBVotes" : "8.5",
    "country" : "United States",
    "yearMovie" : "2018",
    "directedBy" : "Bradley Cooper"
}

*/


/* PATCH

[
	{ "propName": "genreMovie", "value": "Horror"  }
]

*/

/*

Estructura de propName para editar varios campos a la vez:
[
	{
		"propName" : "genreMovie", "value" : "drama"
	}
,
	{
		"propName" : "imDBVotes", "value" : "9.6"
	}
,
	{
		"propName" : "yearMovie", "value" : "2019"
	}
]

*/