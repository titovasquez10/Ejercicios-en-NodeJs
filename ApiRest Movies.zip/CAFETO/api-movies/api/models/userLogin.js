const mongoose = require('mongoose');

const userLoginSchema = mongoose.Schema({

    _id: mongoose.Schema.Types.ObjectId,
    idUser: String,
    nameUser: String,
    commentsMovie: String,
    movieRating: Number,
    registry: {
        idMovie: { type: String, ref: 'Movies'},
        nameMovie: { type: String },
        yearMovie: { type: String },
    }
});
module.exports = mongoose.model('UserLogin', userLoginSchema);


/* POST
{
    "idUser" : "1234",
    "nameUser": "Tito Vasquez",
    "commentsMovie": "La pelicula es super buena, la recomiendo 1000%",
    "movieRating": "2",
    "registry": {
        "idMovie": "0002"
    }
}

*/

/* PATCH

[
	{ "propName": "movieRating", "value": "5"  }
]

*/