const mongoose = require('mongoose');

const userregister1Schema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    idUser: String,
    nameUser: String,
    email: { type: String, 
       required: true, 
       unique: true, 
       match: /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/
   },
   password: { type: String, required: true }
});

module.exports = mongoose.model('UserRegister', userregister1Schema);

/* Signup
{
   "idUser" : "1234",
   "nameUser" : "Tito Vasquez",
   "email" : "tito.10@outlook.com",
   "password" : "12345"
}

{
    "idUser" : "1111",
   "nameUser" : "andres",
    "email" : "andres@gmail.com",
    "password" : "00333"
}

{
    "idUser" : "7676",
   "nameUser" : "Angie Vasquez",
    "email" : "anili92@gmail.com",
    "password" : "0188"
}

*/


/* Forma login EJEMPLO
{
   "email" : "tito.10@outlook.com",
   "password":"12345"
}

*/

