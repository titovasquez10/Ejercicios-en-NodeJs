var _ = require('underscore');

var result = _.contains([1, 2, 3], 2); //UN ARREGLO DEL 1 AL 3 Y SE VA BUSCAR EL 2
console.log(result);