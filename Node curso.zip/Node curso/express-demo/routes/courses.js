const express = require ('express');
const router = express.Router();


//ARREGLO DE COURSES
const courses = [
    {id: 1, name: 'courses1' },
    {id: 2, name: 'courses2' },
    {id: 3, name: 'courses3' },
];

//METODO GET
router.get('/',  (req, res) => {
    res.send(courses);
});

//METODO PARA AGREGAR UN POST
router.post('/', (req, res) => {
    
    //ESTE METODO LLAMA A LA FUNCION DE VALIDAR
    const { error } = validateCourse(req.body);
    if(error) return res.status(400).send(error.details[0].message);
    

    const course = {
        id: courses.length + 1,
        name: req.body.name 
    };
    courses.push(course);
    res.send(course); 
});

router.put('/:id', (req, res) => {
    //ESTAS 2 PRIMERAS LINEAS SON PARA MIRAR SI EXISTE UN COURSE... SI NO EXISTE SE MANDA UN ERROR 404
    const course = courses.find(c => c.id === parseInt(req.params.id));
    if(!course) return res.status(404).send('The course withthe given id was not found..');

    //ESTE METODO LLAMA A LA FUNCION DE VALIDAR
    const { error } = validateCourse(req.body);
    if(error) return res.status(400).send(error.details[0].message);

    //ESTE METODO ACTUALIZA EL COURSE
    course.name = req.body.name;
    res.send(course);
});


router.delete('/:id', (req, res) => {
    
    //ESTAS 2 PRIMERAS LINEAS SON PARA MIRAR SI EXISTE UN COURSE... SI NO EXISTE SE MANDA UN ERROR 404
    const course = courses.find(c => c.id === parseInt(req.params.id));
    if(!course) return res.status(404).send('The course withthe given id was not found..');

    //METODO PARA ELIMINAR
    const index = courses.indexOf(course);
    courses.splice(index, 1);

    //METODO PARA RETORNAR EL COURSE
    res.send(course);
});

//ESTA ES LA FUNCION SCHEMA PARA VALIDAR EL COURSE
function validateCourse(course) {
    const schema = {
        name: Joi.string().min(3).required()
    }
    return Joi.validate(course, schema);
}

router.get('/:id', (req, res) => {
    const course = courses.find(c => c.id === parseInt(req.params.id));
    if(!course) return res.status(404).send('The course withthe given id was not found..');
    res.send(course);
});

module.exports = router;