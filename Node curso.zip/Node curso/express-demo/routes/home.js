const express = require ('express');
const router = express.Router();

//METODO PARA MOSTRAR LA INFORMACION DE LA APP
router.get('/', (req, res) => {
    res.render('index', { title: 'My Express App', message: 'Hello'});
});

module.exports = router;

