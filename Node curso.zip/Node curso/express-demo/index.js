//LLAMADO DE METODOS
const debug = require('debug') ('app:startup');
const config = require('config'); //METODO PARA CONFIGURAR
const morgan = require('morgan');
const helmet = require('helmet');
const Joi = require('joi');
const logger = require('./middleware/logger');
const express = require ('express');
const courses = require('./routes/courses'); //AQUI SE LLAMA LA RUTA DE COURSES LLAMADO DESDE COURSES.JS
const hom = require('./routes/courses')
const app = express();

app.set('view engine', 'pug');
app.set('views', './views'); //default

//DONDE SE EJECUTAN LOS METODOS
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(helmet());
app.use('/api/courses', courses) //CUALQUIER METODO LLAMADO API/COURSES SE DIRECIONARÁ HACIA COURSES
app.use('/', home);
 
//CONFIGURACION 
console.log('Application Name: ' + config.get('name'));
console.log('Mail Server: ' + config.get('mail.host'));
console.log('Mail Password: ' + config.get('password'));

//CODIGO DONDE NOS DICE DONDE ESTA CORRIENDO... SI EN PRODUCTION O DEVELOPMEN MACHINE
if (app.get('env') === 'development'){
    app.use(morgan('tiny'));
    debug('Morgan enable...');
}

app.use(logger);


//MEOTODO PARA SABER SI EL SERVIDOR 3000 FUNCIONA
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Listening on port ${port}...`));