const fs = require('fs');

fs.writeFile('./texto.txt', 'linea uno', function(err){
    if (err) {
        console.log(err);
    }
    console.log('Archivo creado');
});

console.log('ultima linea de codigo')
//SE LE CONOCE COMO UN CALLBAKS
const users = query('SELECT * FROM Users')
