const math = require('./math.js');

console.log(math);

/*
console.log(math.add(1,0));
console.log(math.substract(2,0));
console.log(math.multiply(1,0));
console.log(math.divide(1,0));
console.log(math.divide(2,1));
*/

