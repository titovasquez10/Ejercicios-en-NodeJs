const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/mongo-exercises'); //CONETCION PARA MONGOOSE

//SE LLAMA LA FUNCION SHEMA PARA SABER COMO VAN LAS TABLAS
const courseSchema = new mongoose.Schema({
    name: String,
    author: String,
    tags: [ String ],
    date: Date,
    isPublished: Boolean,
    price: Number
});


const Course = mongoose.model('Course', courseSchema);

//SE CREA UNA FUNCION ASYNC PARA FILTRAR LO Q SE QUIERE OBTENER

//SE QUIERE PUBLICAR TODOS LOS CURSOS QUE VALEN 15 O MAS

async function getCourses(){
    return await Course
    .find({ isPublished: true, })
    .or([ 
        { price: { $gte: 15 } }, //ESTA ES LA CONDICION QUE PERMITE AGREGAR SI TIENE 15 DOLARES O MAS
         { name: /.*by.*/i }
     ])
    .sort('-price')
    .select('name author price');
}

async function run(){
    const courses = await getCourses();
    console.log(courses);
}

run();