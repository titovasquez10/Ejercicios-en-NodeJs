const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/playground') 
    .then(() => console.log('Connected to MongoDB...'))
    .catch(err => console.error('Could not connect to mongoDB...', err)); 

//SCHEMA ES LA COLECCION DE DATOS Y LA DIMENSION Q VA TENER NUESTRO DOCUMENTOS
const courseSchema = new mongoose.Schema({
    name: String,
    author: String, 
    tags: [ String ],
    date: { type: Date, default: Date.now },
    isPublished: Boolean
});

const Course =  mongoose.model('Course', courseSchema);

//FUNCION ASINCRONA 
//SE CREA EL OBJECTO Y UNA FUNCION PASANDO ARCHIVOS SCHEMA
async function createCourse() {
    const course = new Course ({
        name: 'Angular Course',
        author: 'Mosh',
        tags: [ 'angular', 'frontend' ],
        isPublished: true
    });

    const result = await course.save(); //SE GUARDA
    console.log(result); //Y SE MUESTRA EL RESULTADO
}
/*
//METODO PARA GET TODO LOS AGREGADOS
async function getCourses() {
    const courses = await Course.find();
    console.log(courses);
}
*/

//METODO PARA GET PORA ALGO FILTRAR DOCUMENTOS COMO NAME Y TAGS
async function getCourses() {
    const pageNumber = 2;
    const pageSize = 10;

    const courses = await Course
   .find({ author: 'Mosh', isPublished: true }) //SE HACE UN FILTRO PARA TOMAR LOS CAMPOS Q SE DESEA
   
        //.find({ price: {$gt: 10, $lte: 20} }) //SE VA ENCONTRAR SOLO LOS Q TIENEN UN CENTAVOO
        //.find( { price: { $in: [ 10, 15, 20 ] } } ) //SE PASA UN ARREGLO PARA FILTRAR
        /*
        .find({ author: '/ˆtito/'}) //COMIENZA CON TITO
        .find( { author: /Vasquez$/i } )//TERMINA CON VASQUEZ
        */
    .skip((pageNumber -1) * pageSize)
    .limit(pageSize)
    .sort({ name: 1 })
    .select({ name:1, tags: 1 });
    console.log(courses);
}
/*
//METODO PARA ACTUALIZAR LOS CURSOS POR ID
    async function updateCourse(id) {
        const course = await Course.findById(id);
        if(!course) return;

        course.isPublished = true;
        course.author = 'Another Author';

        const result = await course.save();
        console.log(result);
    }
updateCourse('5dfc31736c641826286acc32');

*/

//createCourse();
//getCourses();



//METODO PARA ACTUALIZAR LOS CURSOS POR ID
async function updateCourse(id) {
    const result = await Course.findByIdAndUpdate({ _id: id }, {
     $set: {
         author: 'Jason',
         isPublished: false
     }
    }, { new: true });
    console.log(result);
}
updateCourse('5dfc31736c641826286acc32');

//METODO PARA ACTUALIZAR LOS CURSOS POR ID
async function removeCourse(id) {
 //const result = Course.deleteMany({ _id: id });
 const course = await Course.findByIdAndRemove(id);
 console.log(course);
}

removeCourse('5dfc31736c641826286acc32');