//SE LLAMAN Y SE INICIALIZAN LOS METODOS DE EXPRESS, MONGOOSE
const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const multer = require('multer');
const checkAuth = require('../middleware/check-auth');
const ProductsController = require('../controllers/products');

const storage = multer.diskStorage({
    destination: function(req, file, cb){   //FUNCION DONDE ENCUENTRA DONDE AL IMAGEN ESTA
        cb(null, './uploads/');
    },
    filename: function(req, file, cb){
        cb(null, new Date().toISOString() + file.originalname);   //FUNCION DONDE DICE COMO SE LLAMARA EL FILE
    }
});

const fileFilter = (req, file, cb) => {
    //reject a file
    if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png'){ //SE HACE UNA COMPARACION PARA ACEPTAR EL TIPO DE IMAGEN
        cb(null, true);
    }else {
        cb(null, false);
    }
};   

 //SE CARGA Y SE DA LIMITES A LA IMAGENE Q NO SEA MAYOR DE 5MB
const upload = multer({
    storage: storage, 
    limits: {
    fileSize: 1024 * 1024 * 5
    },
    fileFilter: fileFilter
});


const Product = require("../models/product");

//RUTAS DONDE SE PASAN LOS METOSO
router.get("/", ProductsController.products_get_all);

//METODO PARA AGREGA
router.post("/", checkAuth, upload.single('productImage'), ProductsController.products_create_product);

//METODO DONDE SE TOMA INFO
router.get("/:productId", ProductsController.products_get_product);

router.patch("/:productId", checkAuth, ProductsController.products_update_product);
//METODO DONDE SE ELIMINA
router.delete('/:productId', checkAuth, ProductsController.products_delete);


module.exports = router;