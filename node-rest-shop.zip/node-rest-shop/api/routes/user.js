const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const User = require('../models/user'); //SE IMPORTA LA RUTA DE DONDE SE ENCUENTRA
const UserController = require('../controllers/user');

//METODO PARA QUE USUARIOS DESCONOCIODOS NO BORREN INFORMACION
const checkAuth = require('../middleware/check-auth'); 

//METODO PARA AGREGAR USUARIOS
router.post("/signup", UserController.user_signup);

//SE UTILIZA PARA HACER LOGIN AL USUARIO
router.post("/login", UserController.user_login);

//METODO PARA ELIMINAR USUARIOS
router.delete("/:userID", checkAuth ,UserController.user_delete);

module.exports = router;