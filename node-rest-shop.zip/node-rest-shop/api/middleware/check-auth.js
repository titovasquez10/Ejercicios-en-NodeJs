const jwt = require('jsonwebtoken');

//ESTE METODO VERIFICA SI EL TOKEN EXISTE, ESTA CORRECTO Y PARA Q LOS USUARIOS NO BORREN INFO
module.exports = (req, res, next) => {
    try {
    const token = req.headers.authorization.split(" ")[1];
    console.log(token);    
    const decoded = jwt.verify(token, process.env.JWT_KEY);
    req.userData = decoded;    
    next();
    } catch(error) {
        return res.status(401).json({
             message: 'Auth failed'
        })
    }
    
};