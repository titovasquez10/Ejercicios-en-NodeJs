//METODO PARA CREAR SERVIDOR
const http = require('http');
//SE SOLICITA LA CLASE APP
const app = require('./app'); 

//SE LLAMA UN PUERTO DISPONIBLE O EL PUERTO POR DEFECTO 3000
const port = process.env.PORT || 3000; 

//SE CREA EL SERVIDOR Y SE PASA POR PARAMETRO A (APP)
const server = http.createServer(app);

//SE ENCIENDE EL SERVIDOR
server.listen(port);